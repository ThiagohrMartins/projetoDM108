function Register(date, time, status){
    this.date = date;
    this.time = time;
    this.status = status;
}