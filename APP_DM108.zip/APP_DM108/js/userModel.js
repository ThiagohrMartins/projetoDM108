function User(name, email, password, phone, gender, birth, location ) {
    this.name = name;
    this.email = email;
    this.password = password;
    this.phone = phone;
    this.gender = gender;
    this.birth = birth;
    this.location = location;
}